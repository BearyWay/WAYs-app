import React from "react";

export default function App() {
  return (
    <div style={{ padding: "1rem", fontFamily: "sans-serif" }}>
      <h1>What Matters Most (WMM)</h1>
      <ol>
        <li>Priority 1</li>
        <li>Priority 2</li>
        <li>Priority 3</li>
      </ol>

      <h2>Buttons</h2>
      <button>Power</button>
      <button>Pat on the Back</button>
      <button>Mood Tracker</button>
      <button>Helped Others</button>

      <h2>Start Day</h2>
      <p>Set your mindset and intention for the day.</p>

      <h2>End Day</h2>
      <p>Select one score for each item</p>
      <h3>WMM</h3>
      <ul>
        <li>Priority 1 – [Great / Good / Can Do Better]</li>
        <li>Priority 2 – [Great / Good / Can Do Better]</li>
        <li>Priority 3 – [Great / Good / Can Do Better]</li>
      </ul>

      <h3>Human Tune-Up</h3>
      <ul>
        <li>Sleep – [Great / Good / Can Do Better]</li>
        <li>Nutrition – [Great / Good / Can Do Better]</li>
        <li>Movement – [Great / Good / Can Do Better]</li>
        <li>Stillness – [Great / Good / Can Do Better]</li>
      </ul>
    </div>
  );
}